# Beste student,

de opgave van deze eerste PE - Stel jezelf voor - kan je hier terugvinden: [Opdracht](Opgave/2022-JH1-D-WFB-PE01.pdf)

Succes bij het ontwerpen van de PE!

De lectoren
